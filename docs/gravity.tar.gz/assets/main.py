import pygame
from grav_eng import Body, update
from typing import Optional, List
import asyncio

WIDTH, HEIGHT = 1000, 800
FPS = 60

BLACK  = (10, 10, 12)
YELLOW = (253, 184, 19)
GREEN  = (27, 201, 53)
BLUE   = (67, 144, 198)
RED    = (220, 76, 70)
WHITE  = (240, 240, 240)

class System:
    '''System of bodies interacting (only) gravitationally'''

    def __init__(self, bodies: Optional[List[Body]] = None):
        if bodies:
            self.bodies = bodies
        else:
            self.bodies = [Body(WIDTH / 2, HEIGHT / 2, 0.0, 0.0, 5000.0, 18, YELLOW)]

    def draw_system(self, surf: pygame.Surface):
        '''Draws the system on the screen'''
        for body in self.bodies:
            body.draw(surf)

    def update_system(self):
        '''Updates locations and velocities of every body in the system'''
        update(self.bodies)


async def main() -> None:
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("circles go brrr")
    clock = pygame.time.Clock()
    planets = [
        Body(450, 400, 0, 40, 333000, 20, YELLOW),       # sun 1
        Body(550, 400, 0, -40, 333000, 20, YELLOW),      # sun 2
        Body(100, 400, 0, 40, 1, 6, BLUE),               # blue
        Body(700, 400, 0, -60, 1, 6, RED),               # red
        Body(500, 700, 20, 0, 1, 6, GREEN)
    ]
    sim_universe = System(planets)

    running = True
    paused = False

    while running:
        # 1. Block frame to regulate internal engine rates cleanly
        clock.tick(FPS)
    
        # 2. Parse User Key Signals
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    paused = not paused

        # 3. Advance Mathematics State Machine
        if not paused:
            sim_universe.update_system()

        # 4. Refresh Graphics Pipeline Surfaces
        screen.fill(BLACK)
        sim_universe.draw_system(screen)
        pygame.display.flip()

        # 5. FIXED PLACEMENT: Yield processing back to browser engine safely
        await asyncio.sleep(0)

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
