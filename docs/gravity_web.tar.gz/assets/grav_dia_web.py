from grav_eng_web import Body
#from main import System
import pygame
import math
from typing import List

def kinetic_energy(bodies: List[Body]) -> float:
    K = 0.0
    for b in bodies:
        K += 0.5 * b.mass * ((b.vel[0] ** 2) + (b.vel[1] ** 2))
    return K

def potential_energy(bodies: List[Body], G: float = 1.0):
    U = 0.0
    for i in range(len(bodies)):
        for j in range(i + 1, len(bodies)):
            r = math.dist(bodies[i].pos, bodies[j].pos)
            if r > 0:
                U -= G * bodies[i].mass * bodies[j].mass / r
    return U

def total_energy(system, G: float = 1.0):
    return kinetic_energy(system.bodies) + potential_energy(system.bodies, G)

def linear_momentum(bodies: List[Body]):
    p = [0.0, 0.0]
    for b in bodies:
        for i in range(2):
            p[i] += b.mass * b.vel[i]
    return p

def center_of_mass(bodies: List[Body]):
    total_mass = sum(b.mass for b in bodies)
    x, y = 0.0, 0.0
    for b in bodies:
        x += b.mass * b.pos[0]
        y += b.mass * b.pos[1]
    x /= total_mass
    y /= total_mass
    return [x, y]

def angular_momentum(bodies: List[Body]):
    com = center_of_mass(bodies)
    L = 0.0
    for b in bodies:
        r = b.pos - com
        # 2D cross product: r_x * v_y - r_y * v_x
        L += b.mass * (r[0] * b.vel[1] - r[1] * b.vel[0])
    return L

def maximum_velocity(bodies: List[Body]):
    return max(math.hypot(b.vel[0], b.vel[1]) for b in bodies)

def energy_drift(bodies: List[Body], i_e: float, G: float = 1.0):
    cur = kinetic_energy(bodies) + potential_energy(bodies, G)
    return 100 * (cur - i_e) / i_e


def draw_panel(surf: pygame.Surface, system, i_e):
    font = pygame.font.SysFont("consolas", 18)

    bodies = system.bodies

    # diagnostics
    K = kinetic_energy(bodies)
    U = potential_energy(bodies)
    E = K + U
    p = linear_momentum(bodies)
    L = angular_momentum(bodies)
    com = center_of_mass(bodies)
    max_v = maximum_velocity(bodies)

    drift = (E - i_e) / i_e * 100
    lines = [
        f"Kinetic Energy:     {K:.3f}",
        f"Potential Energy:   {U:.3f}",
        f"Total Energy:       {E:.3f}",
        f"Energy Drift:       {drift:.3f} %",
        f"Linear Momentum:    ({p[0]:.3f}, {p[1]:.3f})",
        f"Angular Momentum:   {L:.3f}",
        f"Center of Mass:     ({com[0]:.1f}, {com[1]:.1f})",
        f"Max Velocity:       {max_v:.3f}"
    ]

    pygame.draw.rect(surf, (20, 20, 20), pygame.Rect(0, 0, 330, len(lines)*22 + 10))
    y = 5
    for line in lines:
        text = font.render(line, True, (240, 240, 240))
        surf.blit(text, (10, y))
        y += 22

    return K, U
