# pygbag: grav_eng_web
import pygame
from grav_eng_web import Body, update, handle_collisions
from grav_dia_web import draw_panel, total_energy
from typing import Optional, List
import asyncio

WIDTH, HEIGHT = 1000, 800
FPS = 60

BLACK  = (10, 10, 12)
YELLOW = (253, 184, 19)
GREEN  = (27, 201, 53)
BLUE   = (67, 144, 198)
RED    = (220, 76, 70)
WHITE  = (240, 240, 240)

class System:
    '''System of bodies interacting (only) gravitationally'''
    def __init__(self, bodies: Optional[List[Body]] = None):
        if bodies:
            self.bodies = bodies
        else:
            self.bodies = [Body(WIDTH / 2, HEIGHT / 2, 0.0, 0.0, 5000.0, 18, YELLOW)]

    def draw_system(self, surf: pygame.Surface, camera):
        '''Draws the system on the screen'''
        for body in self.bodies:
            body.draw(surf, camera)

    def update_system(self):
        '''Updates locations and velocities of every body in the system'''
        update(self.bodies)
        self.bodies = handle_collisions(self.bodies)


class Camera:
    def __init__(self):
        self.zoom = 1.0
        self.offset = [0.0, 0.0]
        self.dragging = False
        self.last_mouse_pos = []

    def wts(self, pos): # world to screen
        return (pos - self.offset) * self.zoom

    def stw(self, pos): # screen to world
        return (pos / self.zoom) + self.offset




async def main() -> None:
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("circles go brrr")
    clock = pygame.time.Clock()

    camera = Camera()

    planets = [
        Body(500, 400, 0, 0, 100000, 30, BLUE),
        #Body(500, 600, 10, 0, 10000, 30, YELLOW),
        Body(50, 200, 0, -10, 1, 4, WHITE)
        
    ]

    # (500, 169), (300, 515), and (700, 515)

    #planets = [
    #    Body(500, 500, 0, 0, 20600, 10, BLUE),
    #    Body(500, 300, 3, 3, 10200, 4, WHITE)        
    #]

    sim_universe = System(planets)
    i_e = total_energy(sim_universe)

    running = True
    paused = False

    while running:    
    
        # 2. Parse User Key Signals
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    paused = not paused
                elif event.key == pygame.K_q:
                    pygame.quit()
            elif event.type == pygame.MOUSEWHEEL:
                camera.zoom *= 1.1 ** event.y

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:   # left click
                    camera.dragging = True
                    camera.last_mouse_pos = list(pygame.mouse.get_pos())
            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    camera.dragging = False
            elif event.type == pygame.MOUSEMOTION:
                if camera.dragging:
                    mouse_pos = list(event.pos)
                    for i in range(2): 
                        camera.offset[i] -= (mouse_pos[i] - camera.last_mouse_pos[i]) / camera.zoom

                    camera.last_mouse_pos = mouse_pos

        # 3. Advance Mathematics State Machine
        if not paused:
            sim_universe.update_system()

        # 4. Refresh Graphics Pipeline Surfaces
        screen.fill(BLACK)

        sim_universe.draw_system(screen, camera)
        draw_panel(screen, sim_universe, i_e)

        pygame.display.flip()

        # 5. FIXED PLACEMENT: Yield processing back to browser engine safely
        await asyncio.sleep(0)

        # 1. Block frame to regulate internal engine rates cleanly
        clock.tick(FPS)
        

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
