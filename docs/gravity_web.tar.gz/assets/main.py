# pygbag: grav_eng_web
import pygame
from grav_eng_web import Body, update, handle_collisions
from grav_dia_web import draw_panel, total_energy
from typing import Optional, List
import asyncio

WIDTH, HEIGHT = 1000, 800
FPS = 60

BLACK  = (10, 10, 12)
YELLOW = (253, 184, 19)
GREEN  = (27, 201, 53)
BLUE   = (67, 144, 198)
RED    = (220, 76, 70)
WHITE  = (240, 240, 240)

class System:
    '''System of bodies interacting (only) gravitationally'''
    def __init__(self, bodies):
        if bodies:
            self.bodies = bodies

    def draw_system(self, surf: pygame.Surface, camera):
        '''Draws the system on the screen'''
        for body in self.bodies:
            body.draw(surf, camera)

    def update_system(self):
        '''Updates locations and velocities of every body in the system'''
        if len(self.bodies) != 0:
            update(self.bodies)
            self.bodies = handle_collisions(self.bodies)

    def add_body(self, coords):
        '''Adds a new body to the system'''
        self.bodies.append(Body(coords[0], coords[1], 0, 0, 1000, 10, YELLOW))

    def clear(self):
        '''Removes all bodies from the system'''
        self.bodies = []


class Camera:
    def __init__(self):
        self.zoom = 1.0
        self.offset = [0.0, 0.0]
        self.dragging = False
        self.last_mouse_pos = []

    def wts(self, pos): # world to screen
        return [(pos[i] - self.offset[i]) * self.zoom for i in range(2)]
#        return (pos - self.offset) * self.zoom

    def stw(self, pos): # screen to world
        return [(pos[i] / self.zoom) + self.offset[i] for i in range(2)]
        #return (pos / self.zoom) + self.offset


async def main() -> None:
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Gravity")
    clock = pygame.time.Clock()

    camera = Camera()

    planets = [
        Body(500, 400, 0, 0, 100000, 30, BLUE),
        Body(50, 200, 0, -10, 1, 4, WHITE)
        
    ]

    sim_universe = System(planets)
    i_e = total_energy(sim_universe)

    running = True
    paused = False

    while running:    
    
        # 2. Parse User Key Signals
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    paused = not paused
                elif event.key == pygame.K_q:
                    pygame.quit()
                elif event.key == pygame.K_c:
                    sim_universe.clear()

            elif event.type == pygame.MOUSEWHEEL:
                camera.zoom *= 1.1 ** event.y

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:   # left click
                    camera.dragging = True
                    camera.last_mouse_pos = list(pygame.mouse.get_pos())
                elif event.button == 3: # right click
                    if paused:
                        mouse_pos = list(pygame.mouse.get_pos())
                        sim_universe.add_body(camera.stw(mouse_pos))

            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    camera.dragging = False
            elif event.type == pygame.MOUSEMOTION:
                if camera.dragging:
                    mouse_pos = list(event.pos)
                    for i in range(2): 
                        camera.offset[i] -= (mouse_pos[i] - camera.last_mouse_pos[i]) / camera.zoom
                    camera.last_mouse_pos = mouse_pos
        
        key_held = pygame.key.get_pressed()

        if key_held[pygame.K_UP]:
            camera.offset[1] -= 15 / camera.zoom
        elif key_held[pygame.K_DOWN]:
            camera.offset[1] += 15 / camera.zoom
        elif key_held[pygame.K_LEFT]:
            camera.offset[0] -= 15 / camera.zoom
        elif key_held[pygame.K_RIGHT]:
            camera.offset[0] += 15 / camera.zoom

        # 3. Advance Mathematics State Machine
        if not paused:
            sim_universe.update_system()

        # 4. Refresh Graphics Pipeline Surfaces
        screen.fill(BLACK)

        sim_universe.draw_system(screen, camera)
        draw_panel(screen, sim_universe, i_e)

        pygame.display.flip()

        # 5. FIXED PLACEMENT: Yield processing back to browser engine safely
        await asyncio.sleep(0)

        # 1. Block frame to regulate internal engine rates cleanly
        clock.tick(FPS)
        

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
